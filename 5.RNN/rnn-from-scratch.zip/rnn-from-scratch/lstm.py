# Size of concatenated hidden + input vector
from preprocessing import getSentenceData
import numpy as np
import matplotlib.pyplot as plt

hidden_size = 100
word_dim = 8000
vocab_size = 20
z_size = hidden_size + vocab_size
X_train, y_train = getSentenceData('data/reddit-comments-2015-08.csv', word_dim)

def sigmoid(x, derivative=False):

    x_safe = x + 1e-12
    f = 1 / (1 + np.exp(-x_safe))

    if derivative: # Return the derivative of the function evaluated at x
        return f * (1 - f)
    else: # Return the forward pass of the function at x
        return f
def tanh(x, derivative=False):

    x_safe = x + 1e-12
    f = (np.exp(x_safe)-np.exp(-x_safe))/(np.exp(x_safe)+np.exp(-x_safe))

    if derivative: # Return the derivative of the function evaluated at x
        return 1-f**2
    else: # Return the forward pass of the function at x
        return f

def softmax(x, derivative=False):

    x_safe = x + 1e-12
    f = np.exp(x_safe) / np.sum(np.exp(x_safe))

    if derivative: # Return the derivative of the function evaluated at x
        pass # We will not need this one
    else: # Return the forward pass of the function at x
        return f


def init_orthogonal(param):
    if param.ndim < 2:
        raise ValueError("Only parameters with 2 or more dimensions are supported.")

    rows, cols = param.shape

    new_param = np.random.randn(rows, cols)

    if rows < cols:
        new_param = new_param.T

    # Compute QR factorization
    q, r = np.linalg.qr(new_param)

    # Make Q uniform according to https://arxiv.org/pdf/math-ph/0609050.pdf
    d = np.diag(r, 0)
    ph = np.sign(d)
    q *= ph

    if rows < cols:
        q = q.T

    new_param = q

    return new_param

def init_lstm(hidden_size, vocab_size, z_size):

    # Weight matrix (forget gate)
    W_f = np.random.randn(hidden_size, z_size)

    # Bias for forget gate
    b_f = np.zeros((hidden_size, 1))

    # Weight matrix (input gate)
    W_i = np.random.randn(hidden_size, z_size)

    # Bias for input gate
    b_i = np.zeros((hidden_size, 1))

    # Weight matrix (candidate)
    # YOUR CODE HERE!
    W_g = np.random.randn(hidden_size, z_size)

    # Bias for candidate
    b_g = np.zeros((hidden_size, 1))

    # Weight matrix of the output gate
    # YOUR CODE HERE!
    W_o = np.random.randn(hidden_size, z_size)
    b_o = np.zeros((hidden_size, 1))

    # Weight matrix relating the hidden-state to the output
    # YOUR CODE HERE!
    W_v = np.random.randn(vocab_size, hidden_size)
    b_v = np.zeros((vocab_size, 1))

    W_f = init_orthogonal(W_f)
    W_i = init_orthogonal(W_i)
    W_g = init_orthogonal(W_g)
    W_o = init_orthogonal(W_o)
    W_v = init_orthogonal(W_v)

    return W_f, W_i, W_g, W_o, W_v, b_f, b_i, b_g, b_o, b_v




def forward(inputs, h_prev, C_prev, p):
    assert h_prev.shape == (hidden_size, 1)
    assert C_prev.shape == (hidden_size, 1)

    # First we unpack our parameters
    W_f, W_i, W_g, W_o, W_v, b_f, b_i, b_g, b_o, b_v = p

    # Save a list of computations for each of the components in the LSTM
    x_s, z_s, f_s, i_s,  = [], [] ,[], []
    g_s, C_s, o_s, h_s = [], [] ,[], []
    v_s, output_s =  [], []

    # Append the initial cell and hidden state to their respective lists
    h_s.append(h_prev)
    C_s.append(C_prev)



    inputs = np.asarray(inputs[0])
    inputs = np.reshape(inputs, (inputs.shape[0],1))
    if(inputs.shape[0]<20):
        padded_inputs = np.zeros((20,1))
        padded_inputs[:inputs.shape[0],:]= inputs
    else:
        padded_inputs = inputs[:20,:]
    print(h_prev.shape)
        # Concatenate input and hidden state
    z = np.row_stack((h_prev, padded_inputs))
    z_s.append(z)

        # Calculate forget gate
    #print(z)
    f = sigmoid(np.dot(W_f, z) + b_f)
    f_s.append(f)

        # Calculate input gate
    i = sigmoid(np.dot(W_i, z) + b_i)
    i_s.append(i)

        # Calculate candidate
    g = tanh(np.dot(W_g, z) + b_g)
    g_s.append(g)


        # Calculate memory state
    C_prev = f * C_prev + i * g
    C_s.append(C_prev)

        # Calculate output gate
    o = sigmoid(np.dot(W_o, z) + b_o)
    o_s.append(o)

        # Calculate hidden state
    h_prev = o * tanh(C_prev)
    h_s.append(h_prev)

        # Calculate logits
    v = np.dot(W_v, h_prev) + b_v
    v_s.append(v)

        # Calculate softmax
    output = softmax(v)
    output_s.append(output)

    return z_s, f_s, i_s, g_s, C_s, o_s, h_s, v_s, output_s






def backward(z, f, i, g, C, o, h, v, outputs, targets, p):

    # Unpack parameters
    W_f, W_i, W_g, W_o, W_v, b_f, b_i, b_g, b_o, b_v = p

    # Initialize gradients as zero
    W_f_d = np.zeros_like(W_f)
    b_f_d = np.zeros_like(b_f)

    W_i_d = np.zeros_like(W_i)
    b_i_d = np.zeros_like(b_i)

    W_g_d = np.zeros_like(W_g)
    b_g_d = np.zeros_like(b_g)

    W_o_d = np.zeros_like(W_o)
    b_o_d = np.zeros_like(b_o)

    W_v_d = np.zeros_like(W_v)
    b_v_d = np.zeros_like(b_v)

    # Set the next cell and hidden state equal to zero
    dh_next = np.zeros_like(h[0])
    dC_next = np.zeros_like(C[0])

    # Track loss
    loss = 0

    for t in reversed(range(len(outputs))):

        # Compute the cross entropy
        targets[t] = targets[t][:20]
        loss += -np.mean(np.log(outputs[t]) * targets[t])
        # Get the previous hidden cell state
        C_prev= C[t-1]

        # Compute the derivative of the relation of the hidden-state to the output gate
        print(targets.shape)
        dv = np.copy(outputs[t])
        dv[np.argmax(targets[t][:20])] -= 1

        # Update the gradient of the relation of the hidden-state to the output gate
        W_v_d += np.dot(dv, h[t].T)
        b_v_d += dv

        # Compute the derivative of the hidden state and output gate
        dh = np.dot(W_v.T, dv)
        dh += dh_next
        do = dh * tanh(C[t])
        do = sigmoid(o[t], derivative=True)*do

        # Update the gradients with respect to the output gate
        W_o_d += np.dot(do, z[t].T)
        b_o_d += do

        # Compute the derivative of the cell state and candidate g
        dC = np.copy(dC_next)
        dC += dh * o[t] * tanh(tanh(C[t]), derivative=True)
        dg = dC * i[t]
        dg = tanh(g[t], derivative=True) * dg

        # Update the gradients with respect to the candidate
        W_g_d += np.dot(dg, z[t].T)
        b_g_d += dg

        # Compute the derivative of the input gate and update its gradients
        di = dC * g[t]
        di = sigmoid(i[t], True) * di
        W_i_d += np.dot(di, z[t].T)
        b_i_d += di

        # Compute the derivative of the forget gate and update its gradients
        df = dC * C_prev
        df = sigmoid(f[t]) * df
        W_f_d += np.dot(df, z[t].T)
        b_f_d += df

        # Compute the derivative of the input and update the gradients of the previous hidden and cell state
        dz = (np.dot(W_f.T, df)
             + np.dot(W_i.T, di)
             + np.dot(W_g.T, dg)
             + np.dot(W_o.T, do))
        dh_prev = dz[:hidden_size, :]
        dC_prev = f[t] * dC

    grads= W_f_d, W_i_d, W_g_d, W_o_d, W_v_d, b_f_d, b_i_d, b_g_d, b_o_d, b_v_d

    # Clip gradients
    #grads = clip_gradient_norm(grads)

    return loss, grads


# Hyper-parameters
num_epochs = 50

# Initialize a new network
z_size = hidden_size + vocab_size # Size of concatenated hidden + input vector
params = init_lstm(hidden_size=hidden_size, vocab_size=vocab_size, z_size=z_size)

# Initialize hidden state as zeros
hidden_state = np.zeros((hidden_size, 1))

# Track loss
training_loss, validation_loss = [], []

# For each epoch
for i in range(num_epochs):

    # Track loss
    epoch_training_loss = 0
    epoch_validation_loss = 0

    # For each sentence in validation set

        # Initialize hidden state and cell state as zeros
    h = np.zeros((hidden_size, 1))
    c = np.zeros((hidden_size, 1))

        # Forward pass
    for i in range(0,100):

        z_s, f_s, i_s, g_s, C_s, o_s, h_s, v_s, outputs = forward(X_train[i:i+1], h, c, params)

        # Backward pass
        loss, gradients = backward(z_s, f_s, i_s, g_s, C_s, o_s, h_s, v_s, outputs, y_train[i:i+1], params)

        W_f, W_i, W_g, W_o, W_v, b_f, b_i, b_g, b_o, b_v = params
        W_f_d, W_i_d, W_g_d, W_o_d, W_v_d, b_f_d, b_i_d, b_g_d, b_o_d, b_v_d = gradients

        # learning rate is 1e-3
        W_f -= (0.001*W_f_d)
        W_i -= (0.001*W_i_d)
        W_g -= (0.001*W_g_d)
        W_o -= (0.001*W_o_d)
        W_v -= (0.001*W_v_d)
        b_f -= (0.001*b_f_d)
        b_i -= (0.001*b_i_d)
        b_g -= (0.001*b_g_d)
        b_v -= (0.001*b_v_d)
        b_o -= (0.001*b_o_d)

        params = W_f, W_i, W_g, W_o, W_v, b_f, b_i, b_g, b_o, b_v
        # Update loss
        epoch_validation_loss += loss


        # Print loss every 5 epochs
        if i % 5 == 0:
            print(loss)





# Plot training and validation loss
epoch = np.arange(len(training_loss))
#plt.figure()
#plt.plot(epoch, training_loss, 'r', label='Training loss',)
#plt.plot(epoch, validation_loss, 'b', label='Validation loss')
#plt.legend()
#plt.xlabel('Epoch'), plt.ylabel('NLL')
#plt.show()
